DELETE FROM cur_frame.full_dcs WHERE 
