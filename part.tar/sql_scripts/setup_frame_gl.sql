DELETE FROM cur_frame_gl.dcs;

--SELECT dc_name,var_name,v1,v2,v3,v4 FROM shader_constants_v4 AS a WHERE a.time_start = (SELECT max(time_start) FROM shader_constants_v4 WHERE dc_name = a.dc_name);
--SELECT dc_name,var_name,v1,v2,v3,v4 FROM ((SELECT * FROM shader_constants_v4) NATURAL JOIN (SELECT dc_name,max(time_start) AS time_start FROM shader_constants_v4 GROUP BY dc_name));

INSERT INTO cur_frame_gl.dcs SELECT * FROM 
	(SELECT * FROM cur_frame.draw_calls) 
	NATURAL JOIN 
	(SELECT 	dc_name,prim_type,vao_id,instancing FROM 
		(SELECT dc_name,prim_type,vao_id,instancing,max(time_start) 
			FROM gl_sync.draw_call_prop WHERE ?1>=time_start GROUP BY dc_name))
	NATURAL JOIN
	(SELECT 	dc_name,program_id FROM 
		(SELECT dc_name,program_id,max(time_start) 
			FROM gl_sync.shader_binding WHERE ?1>=time_start GROUP BY dc_name))
	ORDER BY ?2;

