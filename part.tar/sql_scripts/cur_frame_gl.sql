ATTACH ':memory:' AS cur_frame_gl;
CREATE TABLE cur_frame_gl.dcs(dc_name VARCHAR,prim_type CHAR(2),vao_id INTEGER,instancing BOOLEAN,program_id INTEGER);

