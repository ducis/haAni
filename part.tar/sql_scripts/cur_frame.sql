ATTACH ':memory:' AS cur_frame;
CREATE TABLE cur_frame.draw_calls(dc_name VARCHAR);
