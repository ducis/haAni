ATTACH ':memory:' AS cur_frame;

