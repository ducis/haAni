{-# LANGUAGE ScopedTypeVariables #-}
import Graphics.Rendering.OpenGL
import Graphics.Rendering.OpenGL.Raw
import qualified Graphics.UI.GLUT as U
import Data.Bits
import Foreign.Storable
import Foreign.Ptr
import Foreign.C.String
import qualified Foreign.Marshal as F
import Data.Char
import SQLUtil
import qualified Database.SQLite3 as DB
import GHC.IO.Handle
import GHC.IO.Handle.FD
import qualified Data.Vec as V
import qualified Data.Vec.LinAlg.Transform3D as V
import Text.Printf
import qualified Data.Map as M
import Data.Int
import Control.Concurrent
import Control.Monad

data Renderer = Renderer DB.Database (M.Map String String)


main = do
	(_,[wS,hS,deltaTS,dbS,sceneScript])<-U.getArgsAndInitialize
	putStrLn dbS
	db<-DB.open dbS
--	DB.runScript db "ATTACH ':memory:' AS cur_frame; ATTACH ':memory' AS cur_frame_gl;" []
--	runScript db "CREATE TABLE cur_frame.fasdfas(id INT);CREATE TABLE cur.dfawre(id INT);"
--	DB.runScript db "ATTACH ':memory:' AS cur_frame; CREATE TABLE cur_frame.fasdfas(id INT);CREATE TABLE cur.dfawre(id INT);" []
	--putStr "\n">>runStr db "SELECT * FROM sqlite_master" >>= sequence.map print>>putStr "\n"

	U.initialWindowSize $= U.Size (read wS) (read hS)
	U.initialDisplayMode $= [U.RGBAMode,U.WithAlphaComponent,U.WithDepthBuffer,U.DoubleBuffered]
	wnd<-U.createWindow "Player"
	U.displayCallback $= return ()
	prepackedSQL <- loadPrepackedSQL>>=return.M.fromList

	mapM (\s->DB.runScript db (prepackedSQL M.! s) []) 
		["main","gl","gl_sync","gl_sync_req","cur_frame","cur_frame_gl"]
	cp "DB Initialized."
	forkIO $ void $ readFile sceneScript>>=(\s->DB.runScript db s [])
--	cp "Loaded."

	let rndr = (Renderer db prepackedSQL)
	U.addTimerCallback 0 $ step rndr 0 (fromIntegral (read deltaTS))
	forkOS $ forever $ hFlush stdout>>threadDelay 2100000
	-- forkOS (forever $ syncGL rndr)
	U.idleCallback $= Just (syncGL rndr)
	depthFunc$=Just Lequal
	U.mainLoop
	where
	cp s = putStrLn s>>hFlush stdout
	step rndr i t = do
		U.addTimerCallback t (step rndr (i+1) t)
		showFrame rndr i
		U.swapBuffers
		putStrLn $ "####" ++ show t
		--hFlush stdout

-- forever = sequence_.repeat
loadPrepackedSQL = readFile "sql_scripts/idx">>=mapM f.filter (/=[]).lines
	where
	f nm = readFile ("sql_scripts/"++nm++".sql")>>=return.(,) nm

syncGL (Renderer db ps) = sql "SELECT * FROM gl_sync_reqs_named ORDER BY time_start,type ASC LIMIT 1" []>>= mapM sync>>return () where
	sql = runStrB db
	sync row = let 
		--[nm',ts',tp'] = row 
		--[DB.SQLText nm,DB.SQLInteger ts,DB.SQLText (_:tp)] = row
		[nm',ts',DB.SQLText (_:_:tp)] = row
		in do
		putStr "\nrow\t">>print row
		sql "DELETE FROM gl_sync_reqs_named WHERE (name=?1 AND time_start=?2 AND type=?3)" row
		putStr "tp\t">>print tp
		case tp of
			"g"-> do
				rs'<-sql "SELECT gl_vao_id,max(impl_time_start) FROM gl_sync.geometry_impl WHERE geometry_name=?1 AND ?2>=impl_time_start" [nm',ts']
				vao<- case rs' of
					[[DB.SQLInteger i]]->return (fromIntegral i)
					[]->do	
						i<-F.alloca (\s->glGenVertexArrays 1 s>>peek s)
						putStrLn $ "VAO\t"++show i
						addGLObject "v" i
						sql "INSERT INTO gl_sync.geometry_impl VALUES (?,?,?)" [nm',ts',DB.SQLInteger (fromIntegral i)]
						glBindVertexArray i
						return i
				return ()
--				rs<-sql "SELECT attrib_name,num_elements geometry_data_relational-}
			_-> do
				src<-sql ("SELECT * FROM "++
					(case tp of {"p"->"draw_call_prop";
						"s"->"shader_binding";"cm"->"shader_constants_m44";"cv"->"shader_constants_v4"})
					++" WHERE dc_name=?1 AND time_start=?2") [nm',ts']
				putStr "src\t">>print src
				case tp of 
					"p"-> let [(_:_:ptp':gn':xs')]=src in void $ do
						[[vao']]<-sql "SELECT gl_vao_id,max(impl_time_start) FROM gl_sync.geometry_impl WHERE geometry_name=?1 AND ?2>=impl_time_start" [nm',ts']
						sql "INSERT INTO gl_sync.draw_call_prop VALUES (?,?,?,?,?)" (nm':ts':ptp':vao':xs')
					"s"-> let [(_:_:ss')]=src in void $ do
						sids'<-zipWithM (\a b->if b==DB.SQLText "" then return (DB.SQLInteger (-1)) else syncShader a b) ["v","g","f"] ss'
						rs'<-sql "SELECT program_id FROM gl.gl_programs WHERE vs_id=?1 AND gs_id=?2 AND fs_id=?3" sids'
						pid'<-case rs' of
							[[r']]->return r'
							[]->do
								pid<-glCreateProgram
								mapM_ (\(DB.SQLInteger i)->if i<0 then return () else glAttachShader pid $ fromIntegral i) sids'
								mapM_ (\f->f pid) [glLinkProgram,glValidateProgram]
								--get (validateStatus $ Program pid)>>=print
								get (programInfoLog $ Program pid) >>= putStrLn.("building program... "++)
								let r'=DB.SQLInteger $ fromIntegral pid
								sql "INSERT INTO gl.gl_programs VALUES (?1,?2,?3,?4)" $ sids'++[r']
								return r'
						sql "INSERT INTO gl_sync.shader_binding VALUES (?1,?2,?3)" [nm',ts',pid']
					('c':t)-> void $ do
						[(DB.SQLInteger i:_)]<-sql "SELECT program_id,max(time_start) FROM gl_sync.shader_binding WHERE dc_name=?1 AND ?2>=time_start" [nm',ts']
						mapM_ (\(_:_:DB.SQLText u:xs')->(do
							uid<-withCString u (glGetUniformLocation (fromIntegral i).castPtr)
							printf "uniform location %d" (fromIntegral uid::Int)
							sql ("INSERT INTO gl_sync.shader_constants_"++(case t of {"m"->"m44";"v"->"v4"})
								++" VALUES (?,?,?"++concat (map (\_->",?") xs')++")") (nm':ts':DB.SQLInteger (fromIntegral uid):xs')
							)) src

	syncShader shaderType nm' = syncNamedGLObject (DB.SQLText "s") (loadShader shaderType nm') nm'
	syncNamedGLObject tp' objLoader nm' = do --loader should take care of updating gl.gl_objects 
		rs'<-sql "SELECT gl_id FROM gl.gl_object_naming WHERE type=?1 AND name=?2" [tp', nm']
		case rs' of 
			[[id']] -> return id'
			[] -> do 
				id'<-objLoader>>=return.DB.SQLInteger
				sql "INSERT INTO gl.gl_object_naming VALUES (?1,?2,?3)" [tp',id',nm']
				return id'
	addGLObject tp id = sql "INSERT INTO gl.gl_objects VALUES (?1,?2)" [DB.SQLText tp,DB.SQLInteger $ fromIntegral id]
	loadShader sTp nm' = do
		--get vendor>>=putStrLn.(++"###")
		--glGetString gl_VERSION>>=print --peekCString.castPtr
		id<-glCreateShader (case sTp of {"v"->gl_VERTEX_SHADER;"g"->gl_GEOMETRY_SHADER;"f"->gl_FRAGMENT_SHADER})>>=return.fromIntegral
		--id<-case sTp of {"v"->(genObjectNames 1>>=return.vertexShaderID.head)}>>=return.fromIntegral
		(\s->	acqTextRes sql "s" nm'>>=(shaderSource s$=).(:[])>>
			compileShader s>>putStrLn ("Compiling shader "++(stripSQL nm'))>>get (compileStatus s)>>=print
			>>get (shaderInfoLog s)>>=putStrLn ) (FragmentShader $ fromIntegral id)
		addGLObject "s" id
		sql "INSERT INTO gl.gl_shaders VALUES (?1,?2)" [DB.SQLInteger id,DB.SQLText sTp]
		putStrLn $ printf "loaded shader\t%s %d" ((\(DB.SQLText x)->x)nm') id
		return id

acqTextRes sql tp nm' = sql "SELECT data FROM text_res WHERE type=?1 AND name=?2" [DB.SQLText tp,nm']>>=(\[[DB.SQLText r]]->return r)
acqBinRes sql tp nm' = sql "SELECT data FROM bin_res WHERE type=?1 AND name=?2" [DB.SQLText tp,nm']>>=(\[[DB.SQLBlob r]]->return r)

showFrame (Renderer db ps) (t::Int64) = do
--	s<-DB.prepare db 
--	runstmtb s [t',t']
--	runstmtb s [t',t']
--	runStmtB s [t',t']
--	print "4344143">>hFlush stdout	
	--DB.runScript db (ps M.! "setup_frame") $ [t']--,DB.SQLText "(vertex_shader_name,geometry_shader_name,fragment_shader_name,geometry_name)"]
	mapM (\(s,b)->sql (ps M.! s) b) [
		("setup_frame",		[t']),
		("setup_frame_gl",	[t',txt "(program_id,vao_id)"])
		]
--	print "F3y3sdf">>hFlush stdout
	glClearColor 1 0 0 0
	clear [ColorBuffer,DepthBuffer]
	runStr db "SELECT * FROM cur_frame_gl.dcs;" >>= mapM draw
	where 
	txt = DB.SQLText
	sql = DB.runScript db
	t' = DB.SQLInteger $ fromIntegral t
	draw dc = let (name':_) = dc in do
		print dc



